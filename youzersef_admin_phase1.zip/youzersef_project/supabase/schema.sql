-- Youzersef initial schema (Supabase/Postgres)
-- Run in Supabase SQL Editor. Review policies before production use.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_store_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.admin_users a where a.user_id = auth.uid()); $$;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(10,2) not null check (price >= 0),
  category text not null check (category in ('ready','custom')),
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  address text not null,
  notes text,
  total numeric(10,2) not null check (total >= 0),
  custom_deposit numeric(10,2) not null default 0 check (custom_deposit >= 0),
  status text not null default 'new' check (status in ('new','deposit_pending','confirmed','processing','shipped','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  category text not null check (category in ('ready','custom')),
  unit_price numeric(10,2) not null check (unit_price >= 0),
  quantity integer not null check (quantity > 0),
  design_file_path text
);

create table if not exists public.page_visits (
  id bigint generated always as identity primary key,
  visited_at timestamptz not null default now(),
  path text
);

alter table public.admin_users enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.page_visits enable row level security;

-- Public can read active catalog only. Admins have management rights.
create policy "public reads active products" on public.products for select using (active = true);
create policy "admins manage products" on public.products for all to authenticated using (public.is_store_admin()) with check (public.is_store_admin());
create policy "admins read orders" on public.orders for select to authenticated using (public.is_store_admin());
create policy "admins update orders" on public.orders for update to authenticated using (public.is_store_admin()) with check (public.is_store_admin());
create policy "admins read order items" on public.order_items for select to authenticated using (public.is_store_admin());
create policy "admins manage visits" on public.page_visits for select to authenticated using (public.is_store_admin());

-- No direct anonymous insert policies for orders/order_items: implement checkout via a server-side function
-- that validates product IDs/prices, totals, deposit and uploaded file ownership before inserting.
-- No public write policy for page_visits yet; use a server-side endpoint or tightly scoped RPC.
